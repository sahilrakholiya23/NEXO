SECRET_KEY = 'your_secret_key_here'
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'phantom123'
SENDER_EMAIL = 'your_email@example.com'
SENDER_PASSWORD = 'your_email_password'
RECEIVER_EMAIL = 'your_email@example.com'


